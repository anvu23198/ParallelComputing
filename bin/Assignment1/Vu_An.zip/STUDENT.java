package Assignment1;

public class STUDENT {
	
	public float gpa;
	public int age;
	
	public STUDENT(float gpa, int age) {
		this.gpa = gpa;
		this.age = age;
	}
	
	public float getGpa() {
		return this.gpa;
	}
	
	public int getAge() {
		return this.age;
	}
	
}
