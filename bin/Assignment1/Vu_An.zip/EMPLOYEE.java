package Assignment1;

public class EMPLOYEE {
	
	public int id;
	public int salary;
	
	public EMPLOYEE(int id, int salary) {
		this.id = id;
		this.salary = salary;
	}
	
	public int getId() {
		return this.id;
	}
	
	public int getSalary() {
		return this.salary;
	}
	
}
